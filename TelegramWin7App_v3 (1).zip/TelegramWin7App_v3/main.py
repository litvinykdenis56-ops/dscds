import asyncio
import csv
import os
import sys
from datetime import datetime
from pathlib import Path

from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QApplication, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QMainWindow, QMessageBox, QPushButton, QSpinBox,
    QStackedWidget, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout,
    QWidget, QAbstractItemView, QCheckBox
)
from telethon import TelegramClient
from telethon.errors import (
    PasswordHashInvalidError, PhoneCodeExpiredError, PhoneCodeInvalidError,
    PhoneNumberInvalidError, SessionPasswordNeededError
)

APP_DIR = Path(os.environ.get("APPDATA", Path.home())) / "TelegramWin7App"
SESSION_DIR = APP_DIR / "sessions"
EXPORT_DIR = APP_DIR / "exports"
LOG_DIR = APP_DIR / "logs"
for d in (SESSION_DIR, EXPORT_DIR, LOG_DIR):
    d.mkdir(parents=True, exist_ok=True)
SESSION_PATH = str(SESSION_DIR / "telegram_user")


class TelegramWorker(QThread):
    status = pyqtSignal(str)
    code_requested = pyqtSignal()
    login_success = pyqtSignal(str)
    error = pyqtSignal(str)
    chats_ready = pyqtSignal(list)
    messages_ready = pyqtSignal(list)
    members_ready = pyqtSignal(list)
    send_result = pyqtSignal(str, bool, str)
    queue_done = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.loop = None
        self.client = None
        self.phone = None
        self.code_hash = None
        self.stop_queue = False

    def run(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def submit(self, coro):
        if self.loop:
            asyncio.run_coroutine_threadsafe(coro, self.loop)

    def start_login(self, api_id, api_hash, phone):
        self.submit(self._start_login(api_id, api_hash, phone))

    async def _start_login(self, api_id, api_hash, phone):
        try:
            self.phone = phone.strip()
            self.client = TelegramClient(
                SESSION_PATH, int(api_id), api_hash.strip(),
                device_model="TelegramWin7App", system_version="Windows 7",
                app_version="3.0.0"
            )
            await self.client.connect()
            if await self.client.is_user_authorized():
                self.login_success.emit(self._user_text(await self.client.get_me()))
                return
            result = await self.client.send_code_request(self.phone)
            self.code_hash = result.phone_code_hash
            self.code_requested.emit()
            self.status.emit("Код отправлен.")
        except Exception as e:
            self.error.emit(self._friendly(e))

    def submit_code(self, code):
        self.submit(self._code(code))

    async def _code(self, code):
        try:
            await self.client.sign_in(self.phone, code.strip(), phone_code_hash=self.code_hash)
            self.login_success.emit(self._user_text(await self.client.get_me()))
        except SessionPasswordNeededError:
            self.status.emit("Требуется пароль 2FA.")
            self.code_requested.emit()
        except Exception as e:
            self.error.emit(self._friendly(e))

    def submit_password(self, password):
        self.submit(self._password(password))

    async def _password(self, password):
        try:
            await self.client.sign_in(password=password)
            self.login_success.emit(self._user_text(await self.client.get_me()))
        except PasswordHashInvalidError:
            self.error.emit("Неверный пароль 2FA.")
        except Exception as e:
            self.error.emit(self._friendly(e))

    def load_chats(self, limit=300):
        self.submit(self._load_chats(limit))

    async def _load_chats(self, limit):
        try:
            rows = []
            async for d in self.client.iter_dialogs(limit=limit):
                if d.is_group or d.is_channel:
                    rows.append({"id": d.id, "title": d.name or "", "entity": d.entity})
            self.chats_ready.emit(rows)
        except Exception as e:
            self.error.emit(self._friendly(e))

    def search_messages(self, query, limit=100):
        self.submit(self._search(query, limit))

    async def _search(self, query, limit):
        try:
            rows = []
            async for d in self.client.iter_dialogs(limit=100):
                async for m in self.client.iter_messages(d.entity, search=query, limit=limit):
                    rows.append({
                        "chat": d.name or "", "id": m.id,
                        "date": m.date.strftime("%Y-%m-%d %H:%M") if m.date else "",
                        "text": m.text or ""
                    })
                    if len(rows) >= limit:
                        self.messages_ready.emit(rows)
                        return
            self.messages_ready.emit(rows)
        except Exception as e:
            self.error.emit(self._friendly(e))

    def load_members(self, ref, limit=500):
        self.submit(self._members(ref, limit))

    async def _members(self, ref, limit):
        try:
            entity = await self.client.get_entity(ref)
            rows = []
            async for u in self.client.iter_participants(entity, limit=limit):
                rows.append({"id": u.id, "name": " ".join(x for x in [u.first_name, u.last_name] if x) or "",
                             "username": u.username or ""})
            self.members_ready.emit(rows)
        except Exception as e:
            self.error.emit(self._friendly(e))

    def start_queue(self, targets, text, delay):
        self.stop_queue = False
        self.submit(self._send_queue(targets, text, delay))

    def stop_sending(self):
        self.stop_queue = True
        self.status.emit("Остановка очереди запрошена...")

    async def _send_queue(self, targets, text, delay):
        try:
            for item in targets:
                if self.stop_queue:
                    self.send_result.emit(item["title"], False, "Остановлено")
                    break
                try:
                    # Отправка только в явно выбранные пользователем чаты.
                    await self.client.send_message(item["entity"], text)
                    self.send_result.emit(item["title"], True, "Отправлено")
                except Exception as e:
                    self.send_result.emit(item["title"], False, self._friendly(e))
                await asyncio.sleep(max(1, int(delay)))
            self.queue_done.emit()
        except Exception as e:
            self.error.emit(self._friendly(e))

    @staticmethod
    def _user_text(u):
        return "{} | @{} | ID: {}".format(
            " ".join(x for x in [u.first_name, u.last_name] if x) or "без имени",
            u.username or "нет username", u.id
        )

    @staticmethod
    def _friendly(e):
        if isinstance(e, PhoneNumberInvalidError): return "Неверный номер телефона."
        if isinstance(e, PhoneCodeInvalidError): return "Неверный код."
        if isinstance(e, PhoneCodeExpiredError): return "Код истёк."
        if isinstance(e, ValueError): return str(e)
        return "{}: {}".format(type(e).__name__, e)

    def stop_worker(self):
        if self.loop:
            self.loop.call_soon_threadsafe(self.loop.stop)


class LoginPage(QWidget):
    login = pyqtSignal(str, str, str)
    code = pyqtSignal(str)
    password = pyqtSignal(str)
    def __init__(self):
        super().__init__()
        self.aid, self.ahash, self.phone = QLineEdit(), QLineEdit(), QLineEdit()
        self.code_edit, self.pass_edit = QLineEdit(), QLineEdit()
        self.ahash.setEchoMode(QLineEdit.Password)
        self.pass_edit.setEchoMode(QLineEdit.Password)
        self.code_edit.setEnabled(False); self.pass_edit.setEnabled(False)
        self.login_btn = QPushButton("Подключить")
        self.code_btn = QPushButton("Подтвердить код")
        self.pass_btn = QPushButton("Войти с 2FA")
        self.code_btn.setEnabled(False); self.pass_btn.setEnabled(False)
        self.status = QLabel("Введите данные Telegram.")
        f = QFormLayout()
        f.addRow("API ID:", self.aid); f.addRow("API Hash:", self.ahash)
        f.addRow("Телефон:", self.phone); f.addRow("Код:", self.code_edit)
        f.addRow("2FA:", self.pass_edit)
        b = QHBoxLayout(); b.addWidget(self.login_btn); b.addWidget(self.code_btn); b.addWidget(self.pass_btn)
        l = QVBoxLayout(self); l.addWidget(QLabel("<h2>Telegram Win7 App</h2>")); l.addLayout(f); l.addLayout(b); l.addWidget(self.status); l.addStretch()
        self.login_btn.clicked.connect(lambda: self.login.emit(self.aid.text(), self.ahash.text(), self.phone.text()))
        self.code_btn.clicked.connect(lambda: self.code.emit(self.code_edit.text()))
        self.pass_btn.clicked.connect(lambda: self.password.emit(self.pass_edit.text()))
    def code_step(self):
        self.code_edit.setEnabled(True); self.code_btn.setEnabled(True); self.code_edit.setFocus()
    def two_factor(self):
        self.pass_edit.setEnabled(True); self.pass_btn.setEnabled(True); self.pass_edit.setFocus()


class Dashboard(QWidget):
    def __init__(self):
        super().__init__(); self.account = QLabel("Не подключено"); self.status = QLabel("Статус: ожидание")
        l = QVBoxLayout(self); l.addWidget(QLabel("<h2>Dashboard</h2>")); l.addWidget(self.account); l.addWidget(self.status)
        l.addWidget(QLabel("Выбирай модуль слева. Telegram-подключение общее для всех модулей.")); l.addStretch()


class Chats(QWidget):
    refresh = pyqtSignal()
    def __init__(self):
        super().__init__(); self.rows = []; self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["ID", "Чат", "Выбран"])
        self.table.setSelectionMode(QAbstractItemView.NoSelection)
        self.btn = QPushButton("Загрузить группы и каналы"); self.btn.clicked.connect(self.refresh.emit)
        l = QVBoxLayout(self); l.addWidget(QLabel("<h2>Чаты</h2>")); l.addWidget(self.btn); l.addWidget(self.table)
    def set_rows(self, rows):
        self.rows = rows; self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            self.table.setItem(i, 0, QTableWidgetItem(str(r["id"])))
            self.table.setItem(i, 1, QTableWidgetItem(r["title"]))
            cb = QCheckBox(); cb.setChecked(False); self.table.setCellWidget(i, 2, cb)
    def selected(self):
        out = []
        for i, r in enumerate(self.rows):
            cb = self.table.cellWidget(i, 2)
            if cb and cb.isChecked(): out.append(r)
        return out


class Parser(QWidget):
    search = pyqtSignal(str, int); members = pyqtSignal(str, int)
    def __init__(self):
        super().__init__(); self.msgs = []
        self.q = QLineEdit(); self.q.setPlaceholderText("Ключевое слово")
        self.limit = QSpinBox(); self.limit.setRange(1, 5000); self.limit.setValue(100)
        self.btn = QPushButton("Поиск"); self.export = QPushButton("Экспорт CSV"); self.export.setEnabled(False)
        self.ref = QLineEdit(); self.ref.setPlaceholderText("@username или ID чата"); self.mb = QPushButton("Участники")
        self.t = QTableWidget(0, 4); self.t.setHorizontalHeaderLabels(["Чат","ID","Дата","Текст"])
        l = QVBoxLayout(self); l.addWidget(QLabel("<h2>Парсер / аналитика</h2>")); l.addWidget(self.q)
        r=QHBoxLayout(); r.addWidget(self.limit); r.addWidget(self.btn); r.addWidget(self.export); l.addLayout(r); l.addWidget(self.t)
        l.addWidget(self.ref); l.addWidget(self.mb)
        self.btn.clicked.connect(lambda: self.search.emit(self.q.text(), self.limit.value()))
        self.export.clicked.connect(self.save)
        self.mb.clicked.connect(lambda: self.members.emit(self.ref.text(), self.limit.value()))
    def set_messages(self, rows):
        self.msgs=rows; self.t.setRowCount(len(rows))
        for i,r in enumerate(rows):
            for j,k in enumerate(("chat","id","date","text")): self.t.setItem(i,j,QTableWidgetItem(str(r[k])))
        self.export.setEnabled(bool(rows))
    def save(self):
        p=EXPORT_DIR/("messages_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".csv")
        with open(p,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.DictWriter(f,fieldnames=["chat","id","date","text"]); w.writeheader(); w.writerows(self.msgs)
        QMessageBox.information(self,"Экспорт",str(p))


class Broadcast(QWidget):
    start = pyqtSignal(list, str, int); stop = pyqtSignal()
    def __init__(self):
        super().__init__(); self.targets=[]
        self.info=QLabel("Сначала открой «Чаты» и выбери нужные чаты."); self.text=QTextEdit()
        self.text.setPlaceholderText("Текст сообщения")
        self.delay=QSpinBox(); self.delay.setRange(1,3600); self.delay.setValue(30)
        self.go=QPushButton("Запустить очередь"); self.halt=QPushButton("Стоп"); self.halt.setEnabled(False)
        self.log=QTableWidget(0,3); self.log.setHorizontalHeaderLabels(["Чат","Результат","Подробности"])
        l=QVBoxLayout(self); l.addWidget(QLabel("<h2>Разрешённая рассылка</h2>"))
        l.addWidget(QLabel("Выбираются только чаты, отмеченные тобой в разделе «Чаты». Используй только для разрешённых коммуникаций."))
        l.addWidget(self.info); l.addWidget(self.text)
        r=QHBoxLayout(); r.addWidget(QLabel("Задержка, сек.:")); r.addWidget(self.delay); r.addWidget(self.go); r.addWidget(self.halt); l.addLayout(r); l.addWidget(self.log)
        self.go.clicked.connect(self.run)
        self.halt.clicked.connect(self.stop)
    def set_targets(self, targets):
        self.targets=targets; self.info.setText("Выбрано чатов: {}".format(len(targets)))
    def run(self):
        if not self.targets or not self.text.toPlainText().strip():
            QMessageBox.warning(self,"Рассылка","Выбери чаты и введи текст."); return
        self.log.setRowCount(0); self.go.setEnabled(False); self.halt.setEnabled(True)
        self.start.emit(self.targets,self.text.toPlainText(),self.delay.value())
    def stop(self):
        self.stop.emit(); self.halt.setEnabled(False)
    def result(self, title, ok, detail):
        r=self.log.rowCount(); self.log.insertRow(r)
        self.log.setItem(r,0,QTableWidgetItem(title)); self.log.setItem(r,1,QTableWidgetItem("Отправлено" if ok else "Ошибка")); self.log.setItem(r,2,QTableWidgetItem(detail))
    def done(self):
        self.go.setEnabled(True); self.halt.setEnabled(False)


class SimplePage(QWidget):
    def __init__(self,title,text):
        super().__init__(); l=QVBoxLayout(self); l.addWidget(QLabel("<h2>"+title+"</h2>")); l.addWidget(QLabel(text)); l.addStretch()


class Main(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Telegram Win7 App"); self.resize(1100,720)
        self.worker=TelegramWorker()
        self.login=LoginPage(); self.dashboard=Dashboard(); self.chats=Chats(); self.parser=Parser()
        self.broadcast=Broadcast(); self.logs=SimplePage("Логи","Журнал событий будет расширяться вместе с модулями.")
        self.settings=SimplePage("Настройки","Сессия: %s" % SESSION_DIR)
        self.stack=QStackedWidget()
        for w in (self.dashboard,self.chats,self.parser,self.broadcast,self.logs,self.settings): self.stack.addWidget(w)
        self.nav=QListWidget()
        for x in ("Dashboard","Чаты","Парсер / аналитика","Разрешённая рассылка","Логи","Настройки"): self.nav.addItem(x)
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex); self.nav.setCurrentRow(0)
        c=QWidget(); l=QHBoxLayout(c); l.addWidget(self.nav,1); l.addWidget(self.stack,5); self.setCentralWidget(c)
        self.worker.code_requested.connect(self.login.code_step); self.worker.login_success.connect(self.logged)
        self.worker.status.connect(lambda s:self.dashboard.status.setText("Статус: "+s)); self.worker.error.connect(self.err)
        self.worker.chats_ready.connect(self.chats.set_rows); self.worker.messages_ready.connect(self.parser.set_messages)
        self.worker.members_ready.connect(lambda rows: QMessageBox.information(self,"Участники","Получено: {}".format(len(rows))))
        self.chats.refresh.connect(lambda:self.worker.load_chats(500))
        self.parser.search.connect(self.worker.search_messages); self.parser.members.connect(self.worker.load_members)
        self.broadcast.start.connect(self.worker.start_queue); self.broadcast.stop.connect(self.worker.stop_sending)
        self.worker.send_result.connect(self.broadcast.result); self.worker.queue_done.connect(self.broadcast.done)
        self.worker.start()
        self.show_login()

    def show_login(self):
        self.setCentralWidget(self.login)
        self.login.login.connect(self.worker.start_login); self.login.code.connect(self.worker.submit_code); self.login.password.connect(self.worker.submit_password)

    def logged(self,u):
        self.dashboard.account.setText("Аккаунт: "+u); self.setCentralWidget(self._main_widget); self.nav.setCurrentRow(0)

    @property
    def _main_widget(self):
        w=QWidget(); l=QHBoxLayout(w); l.addWidget(self.nav,1); l.addWidget(self.stack,5); return w

    def err(self,msg):
        if "2FA" in msg or "пароль" in msg.lower(): self.login.two_factor()
        QMessageBox.critical(self,"Telegram",msg)

    def closeEvent(self,e):
        self.worker.stop_worker(); self.worker.wait(2000); e.accept()


if __name__=="__main__":
    app=QApplication(sys.argv); w=Main(); w.show(); sys.exit(app.exec_())
